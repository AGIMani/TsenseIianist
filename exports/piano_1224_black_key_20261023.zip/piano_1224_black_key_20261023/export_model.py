from pathlib import Path
from dm_control import mjcf
from piano_1224 import build
out=Path(__file__).resolve().parent/'model'
out.mkdir(exist_ok=True)
mjcf.export_with_assets(build(),str(out),out_file_name='piano.xml')
print(out/'piano.xml')
