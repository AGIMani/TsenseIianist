"""Run on a remote CPU: verify portable XML and save a standalone MuJoCo MJB."""
import hashlib, json
from pathlib import Path
import mujoco
import numpy as np
root=Path(__file__).resolve().parent
m=mujoco.MjModel.from_xml_path(str(root/'model/piano.xml'))
assert m.njnt==m.nq==88 and m.nu==0
rows=json.loads((root/'data/key_layout.json').read_text())['keys']
assert len(rows)==88
for r in rows:
 i=r['index']; color=r['color']; b=m.body(f'{color}_key_{i}');g=m.geom(f'{color}_key_geom_{i}')
 np.testing.assert_allclose(b.pos*1000,r['body_position_mm'],rtol=0,atol=1e-7)
 site=m.site(f'{color}_key_site_{i}')
 np.testing.assert_allclose(site.size[1]*2000,r['width_mm'],rtol=0,atol=1e-7)
 if color=='black':
  assert int(g.type[0])==int(mujoco.mjtGeom.mjGEOM_MESH)
  mesh=int(g.dataid[0]);start=m.mesh_vertadr[mesh];count=m.mesh_vertnum[mesh]
  rot=np.empty(9);mujoco.mju_quat2Mat(rot,g.quat)
  verts=(m.mesh_vert[start:start+count]@rot.reshape(3,3).T+g.pos)*1000
  expected=np.array(r['body_vertices_mm'])
  assert len(verts)==len(expected)==8
  assert np.max(np.min(np.linalg.norm(verts[:,None,:]-expected[None,:,:],axis=2),axis=1))<1e-4
assert sum(r['color']=='white' for r in rows)==52
assert abs(rows[-1]['center_mm']-rows[0]['center_mm']+22.5-1224)<1e-7
assert abs(m.opt.timestep-.005)<1e-15
assert int(m.opt.integrator)==int(mujoco.mjtIntegrator.mjINT_EULER)
d=mujoco.MjData(m);mujoco.mj_forward(m,d)
for _ in range(20):mujoco.mj_step(m,d)
assert np.isfinite(d.qpos).all() and np.isfinite(d.qvel).all()
assert not np.any(d.warning.number)
mujoco.mj_saveModel(m,str(root/'model/piano.mjb'))
loaded=mujoco.MjModel.from_binary_path(str(root/'model/piano.mjb'))
np.testing.assert_array_equal(loaded.body_pos,m.body_pos)
report={'status':'passed','mujoco':mujoco.__version__,'keys':88,'white':52,'black':36,'total_width_mm':1224,'black_top_mm':[10,90],'black_bottom_mm':[12,95],'black_height_mm':18,'compiled_black_vertices_match_current_preview':True,'cpu_steps':20,'warnings':0,'mjb_roundtrip':'passed','xml_sha256':hashlib.sha256((root/'model/piano.xml').read_bytes()).hexdigest()}
(root/'validation').mkdir(exist_ok=True)
(root/'validation/runtime_check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
