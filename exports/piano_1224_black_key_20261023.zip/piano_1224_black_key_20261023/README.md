# 当前钢琴独立模型（2026-10-23）

88键 A0～C8，52白键、36黑键，总宽1224 mm。白键22.5×150 mm；黑键上表面10×90 mm、底面12×95 mm、高18 mm，上下后端齐平。单位为米、千克、秒、弧度（尺寸图和data/key_layout.json使用毫米）。

## 在当前电脑查看

在项目目录 `/home/hj/pianist` 运行：

```bash
./launch_piano_preview.sh
```

这是已验证MJB的静态查看入口：左键旋转、右键平移、滚轮缩放；1总览、2顶视、3近景、O原点/轴、H双手开关、Esc退出。它使用项目内已有的完整场景MJB；本包只携带钢琴本体，不含双手。保留3 GiB内存保护和至少4 GiB可用内存要求。

## 包内文件

- `model/piano.xml`：独立MJCF，黑键mesh顶点内嵌，无外部网格路径；可导入MuJoCo。
- `model/piano.mjb`：MuJoCo 3.11.0编译的独立钢琴二进制，不含双手；其他MuJoCo版本优先使用XML重新编译。
- `piano_1224/`：独立Python生成器及物理设置，不读取原工程或其他历史工程。
- `original_project/`：当前工程的两份原始几何源码，便于逐文件核对。
- `data/key_layout.json`：88键中心、reference site宽度、黑键顶点和当前场景指法目标坐标。目标坐标只是来源记录；独立模型没有任务奖励或策略。
- `docs/`：尺寸说明、尺寸图及完整场景的近景截图。
- `source.json`、`validation/`、`MANIFEST.sha256`：来源、远端CPU验证、文件散列。

## 在其他机器加载或重新生成

在独立虚拟环境安装 `requirements-runtime.txt` 后，可在Python中加载：

```python
import mujoco
model = mujoco.MjModel.from_xml_path("/绝对路径/model/piano.xml")
# 相同MuJoCo 3.11.0也可加载二进制：
model = mujoco.MjModel.from_binary_path("/绝对路径/model/piano.mjb")
```

生成XML需要 `requirements-build.txt`，运行 `python export_model.py`。编译/物理自检运行 `python verify_model.py`；会更新包内MJB和验证报告。如在本项目执行这些模型编译或物理操作，必须按项目约定放到volc-a32远端，本机只使用上面的现有静态查看入口。

白键为矩形实体，没有实物白键后端缺口；本模型是用户指定的理想几何，不代表实琴测量或硬件标定。质量、显式惯量、键程及接触设置保留当前版本；新黑键形状未按均匀密度重算惯量。100%实际激活属于宿主任务判定，本包不附带训练奖励、声音合成或checkpoint。

验证：远端volc-a32独立目录生成XML，MuJoCo 3.11.0 CPU编译、逐键坐标和黑键顶点核对、20步状态有限且无警告、MJB保存/加载对照通过。未训练或策略演奏。

来源源码保留Apache-2.0声明，许可见LICENSE。
