"""Standalone 1224 mm piano; SI units; no external project imports."""
import json
from pathlib import Path
from .piano_mjcf import build as build_geometry


def build(add_actuators=False):
    """Apply the validated 200 Hz piano physics to the original geometry builder."""
    root = build_geometry(add_actuators=add_actuators)
    settings = json.loads(Path(__file__).with_name("physics.json").read_text())
    for attr in ("solref", "solimp", "friction", "priority"):
        setattr(root.default.geom, attr, settings["piano"][attr])
    root.default.joint.solreflimit = settings["key_limit"]["solref"]
    root.default.joint.solimplimit = settings["key_limit"]["solimp"]
    root.option.timestep = settings["physics_dt"]
    root.option.integrator = settings["integrator"]
    root.option.impratio = settings["impratio"]
    return root
