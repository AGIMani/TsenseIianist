"""CPU-only compilation checks of the portable MJCF and supplied coordinates."""
import argparse
import json
from pathlib import Path
import mujoco
import numpy as np

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--xml', type=Path, default=Path(__file__).resolve().parent/'model/piano.xml')
p.add_argument('--report', type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parent
m=mujoco.MjModel.from_xml_path(str(a.xml))
rows=json.loads((root/'data/key_layout.json').read_text())['keys']
assert m.njnt==88 and m.nq==88 and m.nu in (0,88)
centers=np.zeros(88)
for r in rows:
 i=r['index'];color=r['color'];body=m.body(f'{color}_key_{i}');geom=m.geom(f'{color}_key_geom_{i}')
 centers[i]=body.pos[1]*1000
 np.testing.assert_allclose(centers[i],r['center_mm'],atol=1e-9,rtol=0)
 np.testing.assert_allclose(geom.size[1]*2000,r['width_mm'],atol=1e-9,rtol=0)
white=[r for r in rows if r['color']=='white']
assert len(white)==52 and len(rows)-len(white)==36
assert abs(centers[-1]-centers[0]+22.5-1224)<1e-9
for octv in range(7):
 k=12*octv
 np.testing.assert_allclose(centers[k+6]-centers[k+4],28.2705882352941,atol=1e-9,rtol=0)
 for i,j in ((9,11),(11,13)):
  np.testing.assert_allclose(centers[k+j]-centers[k+i],26.9243697478992,atol=1e-9,rtol=0)
assert abs(m.opt.timestep-.005)<1e-15
assert int(m.opt.integrator)==int(mujoco.mjtIntegrator.mjINT_EULER)
np.testing.assert_allclose(m.geom_solref,np.tile([.01,1.],(m.ngeom,1)),atol=1e-12,rtol=0)
result=dict(status='passed',mujoco=mujoco.__version__,keys=88,white_keys=52,black_keys=36,
 total_width_mm=1224,white_width_mm=22.5,black_width_mm=12,twin_center_mm=28.2705882352941,
 triple_center_mm=26.9243697478992,physical_hz=200,training_started=False)
if a.report:
 a.report.parent.mkdir(parents=True,exist_ok=True)
 a.report.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
