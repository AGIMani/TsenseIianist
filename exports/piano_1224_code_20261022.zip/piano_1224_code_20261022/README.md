# 新钢琴独立代码包：1224 mm

这是当前仿真中新钢琴的MuJoCo/MJCF建模代码与可直接加载的XML。包含88键（A0～C8）、尺寸表、标注图、运行验证和原项目对应源码。键体由box组成，不依赖OBJ/STL网格。

## 布局

- 总宽1224 mm，白键宽22.5 mm，黑键宽12 mm。
- 白键间隙1.0588235294 mm，节距23.5588235294 mm。
- 两黑键组内中心距28.2705882353 mm。
- 三黑键组内相邻中心距26.9243697479 mm。
- 跨组中心距41.3962184874 mm。
- 钢琴局部Y为键盘横向，白键外边缘−0.612/+0.612 m；X为前后，Z为高度。代码/XML长度单位m、质量kg、角度rad；data/key_layout.json为mm。

这是用户指定的理想分组布局，不是DIN 8996或Casio PX-S1100实测模型。白键仍为原有矩形碰撞体。

## 文件

- `piano_1224/piano_constants.py`：尺寸、质量、惯量、关节弹簧等。
- `piano_1224/piano_mjcf.py`：88键生成器；仅改原项目的导入路径和返回类型注解，几何算法不变。
- `piano_1224/__init__.py`、`physics.json`：应用已经验证的200 Hz钢琴接触参数和Euler积分器；控制周期记录为20 Hz。
- `model/piano.xml`：可直接导入MuJoCo的被动钢琴，无手模型、无琴键驱动器。
- `data/key_layout.json`：全部88键的中心位置、宽度、MIDI编号。
- `docs/layout.png`、`layout.svg`：尺寸标注图。
- `original_project/`：三份原项目文件的原样快照，仅供原项目集成/核对。`suite/tasks/base.py`保留原手腕工作区，不应单独当作可运行环境。
- `validation/`：独立导出、MuJoCo3.11.0加载验证和与原生成器逐数组比较结果。
- `source.json`、`MANIFEST.sha256`：来源和完整性记录。

## 直接使用XML

XML不依赖dm-control，也不需要当前工程。已在MuJoCo3.11.0验证：

```python
from pathlib import Path
import mujoco
model = mujoco.MjModel.from_xml_path(str(Path('model/piano.xml').resolve()))
data = mujoco.MjData(model)
```

可使用独立用户虚拟环境安装`requirements-runtime.txt`。在本项目内构建/编译模型仍遵守项目远端执行约定，不因为此代码包改变运行规则。

## 修改代码后重新导出

构建端已验证Python3.12、dm-control1.0.46、MuJoCo3.13.0；运行端已验证MuJoCo3.11.0。建议使用分离的用户虚拟环境：

```bash
python3 -m venv .venv-build
.venv-build/bin/python -m pip install -r requirements-build.txt
MUJOCO_GL=disable .venv-build/bin/python export_model.py
MUJOCO_GL=disable .venv-build/bin/python verify_model.py
```

如果需要自驱动琴键，可显式增加`--actuators --output model/piano_actuated.xml`；原手指按键模型不启用该选项。默认导出没有训练、策略或演奏逻辑。

## 物理保留与接入说明

白键/黑键长度150/90 mm、质量0.04/0.02 kg、键程及原弹簧/阻尼/armature保持。为满足仅更改布局的要求，黑键和基座显式保持修改前的惯量/质量，不按新宽度自动重新计算。模型允许手—琴接触，琴键之间的碰撞过滤继承原设置。

包内只包含钢琴几何与物理参数，未包含手模型、奖励算法、触键激活分类器、训练脚本或检查点。奖励及激活规则由接入的宿主任务决定，不能把本包当作完整训练工程。`docs/project_layout_notes.md`是布局修改时的历史项目说明，其中项目路径及当时任务级门槛不属于本包独立运行接口。

保留原RoboPianist来源Apache-2.0版权头，许可证见LICENSE。
