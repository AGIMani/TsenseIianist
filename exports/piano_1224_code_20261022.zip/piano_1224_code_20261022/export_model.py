"""Generate portable MJCF XML, requiring only this package and build dependencies."""
import argparse
from pathlib import Path
from piano_1224 import build

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'model/piano.xml')
p.add_argument('--actuators', action='store_true', help='Optional torque actuators; disabled in the hand-driven model')
a = p.parse_args()
a.output.parent.mkdir(parents=True, exist_ok=True)
root = build(add_actuators=a.actuators)
assert not root.get_assets(), 'This piano uses primitive boxes, no mesh files'
a.output.write_text(root.to_xml_string())
print(a.output.resolve())
